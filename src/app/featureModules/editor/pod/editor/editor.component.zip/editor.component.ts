import { Component, ViewChild, ElementRef, Renderer2, AfterViewInit, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { observable, Subject } from 'rxjs'
import { ProjectDataService } from '../services/project-data.service';
import { editorHttpService } from './editorFrame-services/editorHttp.service';
import { editorDomService } from './editorFrame-services/editorDom.service';
import { editorJsonService } from './editorFrame-services/editorJson.service';
import { EditorSaveService } from './editorFrame-services/editorSave.service'
import { htmlEncode, htmlDecode } from 'js-htmlencode';
import { Subscription } from 'rxjs'
import { AppConfig } from '../../../../app-config';
import { NgxSpinnerService } from 'ngx-spinner';
import { DOCUMENT } from "@angular/platform-browser";
import { Router, NavigationEnd, ActivatedRoute, NavigationExtras, NavigationStart } from "@angular/router";
import { DomSanitizer } from '@angular/platform-browser';
import { _ } from 'underscore';
import { ProcessPDFService } from '../services/pdf/process-pdf.service';
import { ColorEvent } from 'ngx-color';
import { MatSnackBar } from '@angular/material/snack-bar';
import {NgbActiveModal,NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ModalboxComponent} from '../../../../modalbox/modalbox.component';

@Component({
	selector: 'editor-html',
	templateUrl: './editor.component.html',
	 providers:[editorDomService],

})

export class EditorComponent implements AfterViewInit, OnInit {
	APIUrl;
	chapterFile = "http://172.24.175.33/princeXML_new/";
	tocContent;
	error = true;
	chaptersList;
	pdfSrc;
	pageVariable: any;
	projectName;
	chapterCount;
	editIcon = false;
	project_id = "";
	tocData = {};
	viewer;
	contentdocument: any;
	firstload: number = 1;
	selectedElement;
	selectedToc;
	indexval;
	uploadURL: any;
	chapter: any;
	pageno: any;
	pagenoval: any;
	loginuserrole;
	tocdetail: any;
	tocdetails: any;
	chapterDetails: any;
	currentChapter: any;
	routerSegments: Array<any> = [];
	routePath: any;
	projectCount;
	enable_icon: boolean = false;
	isSave: boolean = false;
	chapterinfo:any;
	button_disable: boolean = true;
	page_model: any = {
		sectionArray: [],
		iframeBody: '',
		sectionCount: 0,
		json: '',
		deleteArray:[],
		isRecursive: ''
	};
	trig: string = '';
	colors = ['#000000', '#DB3E00', '#FCCB00', '#008B02', '#006B76', '#1273DE', '#004DCF', '#5300EB', '#EB9694', '#FAD0C3', '#FEF3BD', '#C1E1C5', '#BEDADC', '#C4DEF6', '#BED3F3', '#D4C4FB']
	public dialogRef: any;
	public IsEditOption: any;
	eventArray: any = [];
	actionBold;
	actionBlock;
	actionP;
	actionItalic;
	actionUnderline;
	actionStrike;
	actionSub;
	actionSuper;
	actionPageBreak;
	actionOl;
	actionUl;
	actionH1;
	actionIndent;
	actionH2;
	actionCreateLink;
	actionUnLink;
	rightAllign;
	leftAllign;
	centerAllign;
	foreColor;
	colorPicker: boolean = false;
	activePage;
	isShowPageTitle: boolean = true;
	isTypeList: boolean;
	public contentDoc: any = '';
	public test_contentDoc: any = '';
	private htmlString: any = '';
	@ViewChild('iframe') public iframeElement: ElementRef;
	@ViewChild('iframetest') public iframeElement_test: ElementRef;
	constructor(public http: HttpClient,
		private sanitizer: DomSanitizer,
		public renderer: Renderer2,
		public dataservice: ProjectDataService,
		public editorHttpService: editorHttpService,
		public editorDomService: editorDomService,
		public editorJsonService: editorJsonService,
		public editorSaveService: EditorSaveService,
		private appConfig: AppConfig,
		private spinner: NgxSpinnerService,
		private router: Router,
		private activatedRoute: ActivatedRoute,
		private processpdfservice: ProcessPDFService,
		private _snackBar: MatSnackBar,
		private modalService: NgbModal
	) {

		//super(editorHttpService, editorDomService, editorJsonService, renderer)

		this.APIUrl = appConfig.config.apiURL;
		this.uploadURL = this.appConfig.config.uploadsURL;
		router.events.subscribe(event => {
			if (event instanceof NavigationEnd) {
				if (event.url.indexOf("editor") != -1) {
					this.viewer = false;
				} else {
					this.viewer = true;
				}
			}
		});
	}

	ngOnInit() {
		this.onloadChapter();
		
	}
	ngOnDestroy(){
	console.log("yes destroyed");
}
	ngAfterViewInit() {

	}
	timeout = function (ms) {
		return new Promise(resolve => setTimeout(resolve, ms));
	}
	saved_pageno: number = 0;
	chapter_pagecount: number = 0;
	nodeToDelete:any='';
	deletedArray:any=[];
	onDeleteNode  = function(){
		this.page_model.deleteArray.push(this.nodeToDelete.getAttribute('uniqid'));
		this.nodeToDelete.parentNode.removeChild(this.nodeToDelete)
	}

	/**1st step to get html file  */
	getHTMLservice = async function (isSave) {
		
		this.spinner.show();
		this.page_model.sectionArray = [];
		this.page_model.iframeBody = '',
			this.page_model.json = '';

		this.page_model.isRecursive = false;
	
		try {

			this.contentDoc = this.iframeElement.nativeElement.contentDocument;
			let contentEdit;
			localStorage.getItem("editaccess")=='0'?contentEdit="false":contentEdit="true";

			this.contentDoc.body.setAttribute("contentEditable", contentEdit);
			this.contentDoc.body.setAttribute("data-gramm",false)
			

			if (this.page_model.sectionCount % 2 == 0)
				this.contentDoc.body.classList.add('pagebreak_spi_even')
			else
				this.contentDoc.body.classList.add('pagebreak_spi_odd')

			let responseData = await this.http.get(this.appConfig.config.apiURL + "/readfile", {
				params: {
					'url': this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + this.currentChapter.pc_name + '.html'
				}
			}).toPromise();
			
			let project_path = this.uploadURL + this.projectName;
			project_path = project_path.replace(new RegExp("../pod_assets/uploads/", "g"), "/pod_assets/uploads/");
		
		

			let data = await this.editorJsonService.createJSONfromHTML(responseData, this.contentDoc, false, this.appConfig.config.hostURL + project_path);
	
			for (let x in data) {
				await this.editorHttpService.creatJSONservice(data[x].data, this.contentDoc, data[x].fileName, this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/');
			}
			for (let x in data) {
				if (data[x].fileName == 'editorHeadJSON') {
					await this.editorDomService.appendIframeHeadContent(JSON.parse(data[x].data), this.contentDoc)
				} else {
					this.page_model.json = JSON.parse(data[x].data);
					let _data: any = '';
					this.test_contentDoc = this.iframeElement_test.nativeElement.contentDocument;
					this.test_contentDoc.head.innerHTML = '';
					this.test_contentDoc.body.innerHTML = '';
					this.test_contentDoc.head.innerHTML = this.contentDoc.head.innerHTML;
					this.page_model.sectionCount = this.saved_pageno;
					if (!isSave) {
						// console.log(this.index);
						// if(this.index>25)
						// 	(document.getElementById("ch_name")).scrollTop=1000;
						this.chapter_pagecount=0;
					
						_data = await this.editorDomService.appendIframePageWiseContent(this.page_model, this.contentDoc, '');
						// console.log(this.contentDoc.body.innerHTML);
						this.test_contentDoc.body.innerHTML = this.contentDoc.body.innerHTML;
			
						this.contentDoc.body.innerHTML = '';
					} else {
						this.test_contentDoc.body.innerHTML = this.contentDoc.body.innerHTML;
						  this.contentDoc.body.innerHTML = '';
				
						_data = await this.editorDomService.appendIframePageWiseContent(this.page_model, this.test_contentDoc, '');
					}
				
					this.contentDoc.body.setAttribute('isbelongTo', 'page_' + this.saved_pageno);
					if (!isSave) {
						// console.log(_data.sectionArray[this.saved_pageno]);
						this.contentDoc.body.innerHTML = _data.sectionArray[this.saved_pageno].outerHTML;
						this.contentDoc.body.onclick = this.editorDomService.mouseClickEvent;
						this.contentDoc.body.onkeypress = this.editorDomService.onkeyPressEvent;
						// this.contentDoc.body.oncopy=this.editorDomService.copiedElement;
						this.contentDoc.body.onpaste=this.editorDomService.pasteElement
						// console.log(this.currentChapter.chapter_name!="remarks")
						// console.log(this.currentChapter.chapter_name);
						// this.chapter_pagecount=(this.currentChapter.chapter_name!="remarks")?this.contentDoc.body.querySelector('div').getAttribute("pagenum"):"";
						this.chapter_pagecount=(this.currentChapter.chapter_name!="remarks")?this.contentDoc.body.querySelector('div').getAttribute("pagenum"):"";
						this.headerValue();
				
						this.spinner.hide();
					}
				
					this.page_boolean_even = this.contentDoc.body.classList.contains('pagebreak_spi_odd') ? true : false;
					this.isSave = true;
					await this.continousPagingFunction(_data);
					
					if(this.break_continous){
						this.contentDoc.body.innerHTML=''
						this.page_model.sectionArray=[];
						this.contentDoc.head.innerHTML='';
						this.changeHtml(this.test_toc,this.test_index)
					}else{
						this.page_model.sectionCount = this.saved_pageno;
						this.button_disable = false;
					}

					
				}
			}
			console.log('1st resolved')
		 this.createUniqIdHTML()
		
		} catch (error) {
			console.log(error)
		}
	}

	continousPagingFunction = async function (data) {
		if (this.isSave && (this.page_model.sectionArray[this.saved_pageno] != '' && this.page_model.sectionArray[this.saved_pageno] != undefined)) {
			//console.log(this.page_model,"page_model")
  			if (this.contentDoc.body.innerHTML == '')
  				this.contentDoc.body.innerHTML = this.page_model.sectionArray[this.saved_pageno].innerHTML;
			// 	let section_elements = this.contentDoc.body.querySelectorAll('body > *');
			// 	Array.prototype.slice.call(section_elements).map((e) => {
			// 	e.addEventListener("click", this.editorDomService.mouseClickEvent);
			// })
			this.spinner.hide();
		}

		if (this.page_model.isRecursive) {

			if (this.page_model.sectionArray.length % 2 == 0)
			   { this.test_contentDoc.body.classList.remove('pagebreak_spi_odd')
				this.test_contentDoc.body.classList.add('pagebreak_spi_even')}
			else
			  {  this.test_contentDoc.body.classList.remove('pagebreak_spi_even')
				this.test_contentDoc.body.classList.add('pagebreak_spi_odd')}

			let _data = await this.editorDomService.appendIframePageWiseContent(data, this.test_contentDoc, '');
			if(this.break_continous)
				return


			await this.continousPagingFunction(_data)
		} else {
			this.test_contentDoc.body.innerHTML = '';
			data.sectionArray.forEach((x) => {
				this.test_contentDoc.body.innerHTML += x.outerHTML;
			})
			console.log('completed')
		}
	
		new Promise((resolve, reject) => {
			resolve(true)
		})
		
	

	}
	/** function to create mock html in test iframe */
	createUniqIdHTML = async function () {
		// try {
		// 	this.test_contentDoc_head = this.test_contentDoc.head.innerHTML;
		// 	this.test_contentDoc_body = this.test_contentDoc.body.innerHTML;
		// 	this.test_contentDoc.body.innerHTML = '';
		// 	this.test_contentDoc.head.innerHTML = '';
		// 	let data: any = [{
		// 		fileName: 'editorHeadJSON'
		// 	}, {
		// 		fileName: 'editorBodyJSON'
		// 	}];
		// 	for (let x in data) {
		// 		data[x].data = await this.http.get(this.appConfig.config.apiURL + "/readfile", {
		// 			params: {
		// 				'url': this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + data[x].fileName + ".json"
		// 			}
		// 		}).toPromise();
		// 	}

		// 	for (let x in data) {
		// 		if (data[x].fileName == 'editorBodyJSON') {
		// 			let test_data: any = {
		// 				json: ''
		// 			}
		// 			test_data.json = JSON.parse(data[x].data)
		// 			await this.editorSaveService.appendIframePageWiseContent(test_data, this.test_contentDoc, '', true, true)
		// 		} else {
		// 			await this.editorSaveService.appendIframeHeadContent(JSON.parse(data[x].data), this.test_contentDoc, true)
		// 		}
		// 	}
			await this.editorHttpService.createHtml({
				head: htmlEncode(this.test_contentDoc.head.innerHTML),
				body: htmlEncode(this.test_contentDoc.body.innerHTML),
				url: this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + 'editorUniqID.html'
			});
		// 	this.enable_icon = true;
		// 	this.test_contentDoc.body.innerHTML = '';
		// 	this.test_contentDoc.head.innerHTML = '';
		// 	this.test_contentDoc.head.innerHTML = this.test_contentDoc_head;
		// 	this.test_contentDoc.body.innerHTML = this.test_contentDoc_body;
		// 	// this.spinner.hide();
		// } catch (error) {
		// 	console.log(error)
		// }
	}
	/**page navigation */
	page_boolean_even: boolean = true;
	pageNavigation = async function (state) {
		this.isSave = false;
		this.editorDomService.eventArray && this.editorDomService.eventArray.map((elem) => {
			if (elem && elem.target) {
				elem.target.style.border = "";
                elem.target.style.boxShadow = "";
                elem.target.style.padding = ""
                elem.target.style.borderRadius = ""
			}
			if (elem.target && elem.target.parentNode) {
				elem.target.parentNode.style.border = "";
                elem.target.parentNode.style.boxShadow = "";
                elem.target.parentNode.style.padding = ""
                elem.target.parentNode.style.borderRadius = ""
			}
			if (elem.target && elem.target.parentNode && elem.target.parentNode.parentNode) {
				elem.target.parentNode.parentNode.style.border = "";
				elem.target.parentNode.parentNode.style.border = "";
				elem.target.parentNode.parentNode.style.boxShadow = "";
				elem.target.parentNode.parentNode.style.padding = ""
				elem.target.parentNode.parentNode.style.borderRadius = ""
			}
		})
		let editorSlide = document.getElementById("editor_newframe");
		if (editorSlide) {
			editorSlide.style.display = 'none';
		}
		

		let _Id = this.contentDoc.body.hasAttribute('isbelongTo') ? JSON.parse(this.contentDoc.body.getAttribute('isbelongTo').split('_')[1]) : '';
	this.page_model.sectionArray[_Id].innerHTML=this.contentDoc.body.innerHTML;
		
		this.asideVisible = !this.asideVisible;
		if (state == 'next' && (_Id <= this.page_model.sectionArray.length - 1)) {

			_Id++;
		
			if (!this.page_model.isRecursive && (_Id > this.page_model.sectionArray.length - 1))
				return

			this.spinner.show();




			if (this.page_model.sectionArray[_Id] != '' && this.page_model.sectionArray[_Id] != undefined) {
				if (_Id % 2 == 0) {
					this.contentDoc.body.classList.remove('pagebreak_spi_odd')
					this.contentDoc.body.classList.add('pagebreak_spi_even')
					this.page_boolean_even = false;
				} else {
					this.contentDoc.body.classList.remove('pagebreak_spi_even')
					this.contentDoc.body.classList.add('pagebreak_spi_odd')
					this.page_boolean_even = true;
				}

				this.page_model.sectionCount = _Id
				this.contentDoc.body.innerHTML = '';
				// this.contentDoc.body.onclick = this.editorDomService.mouseClickEvent;
				this.contentDoc.body.innerHTML = this.page_model.sectionArray[_Id].innerHTML;
				this.contentDoc.body.setAttribute('isbelongTo', 'page_' + _Id);
				//this.button_disable=false;
				this.chapter_pagecount++;
				this.isShowPageTitle = this.chapter_pagecount === 1 ? true  : false;
			} else {
				this._snackBar.open('PAGES ARE STILL IN PROGRESS', '', {
					duration: 3000
				})
			}

		} else if (state == 'previous' && _Id > 0) {

			this.spinner.show();
			_Id--;
		


			if (this.page_model.sectionArray[_Id] != '' && this.page_model.sectionArray[_Id] != undefined) {
				if (_Id % 2 == 0) {
					this.contentDoc.body.classList.remove('pagebreak_spi_odd')
					this.contentDoc.body.classList.add('pagebreak_spi_even')
					this.page_boolean_even = false;
				} else {
					this.contentDoc.body.classList.remove('pagebreak_spi_even')
					this.contentDoc.body.classList.add('pagebreak_spi_odd')
					this.page_boolean_even = true;
				}
				this.contentDoc.body.innerHTML = '';
				this.page_model.sectionCount = _Id
				// this.contentDoc.body.onclick = this.editorDomService.mouseClickEvent;
				this.contentDoc.body.innerHTML = this.page_model.sectionArray[_Id].innerHTML;
				this.contentDoc.body.setAttribute('isbelongTo', 'page_' + _Id);
				this.chapter_pagecount--;
				this.isShowPageTitle = this.chapter_pagecount === 1 ? true  : false;
				//this.button_disable=false;
			}
		}
		
		this.spinner.hide();
	}

	/** function on save */
	onSaveHtml = async function (pdf) {
		this.spinner.show();
		this.eventArrayHandler();
		let editorSlide = document.getElementById("editor_newframe");
		if (editorSlide) {
			editorSlide.style.display = 'none';
		}
		this.test_contentDoc.body.innerHTML = '';
		 this.saved_pageno = this.contentDoc.body.hasAttribute('isbelongTo') ? JSON.parse(this.contentDoc.body.getAttribute('isbelongTo').split('_')[1]) : '';
		
		this.page_model.sectionArray.forEach((x) => {
			if (x.getAttribute('id').split('_')[1] == this.contentDoc.body.getAttribute('isbelongTo').split('_')[1]) {
				this.test_contentDoc.body.innerHTML += this.contentDoc.body.innerHTML;
			}else{
				this.test_contentDoc.body.innerHTML += x.innerHTML
			}
		})
		this.button_disable=true;
		let data = await this.editorJsonService.createSaveJSON(this.test_contentDoc.body);
		this.page_model.newData = data;
		await this.editorSaveService.appendIframePageWiseContent(this.page_model,this.contentDoc,'','')
		let project_path = this.uploadURL + this.projectName;
		project_path = project_path.replace(new RegExp("../pod_assets/uploads/", "g"), "/pod_assets/uploads/");
		let modified_data = await this.editorJsonService.createJSONfromHTML(this.contentDoc.childNodes[0].innerHTML, this.test_contentDoc, true, this.appConfig.config.hostURL + project_path);
		await this.resetJSONHTML(modified_data);
		this.getHTMLservice(true);
		// console.log('data',data)

		// this.button_disable = true;
		// this.saved_pageno = this.contentDoc.body.hasAttribute('isbelongTo') ? JSON.parse(this.contentDoc.body.getAttribute('isbelongTo').split('_')[1]) : '';
		// this.page_model.sectionCount = 0;
		// this.spinner.show();
		// let url = this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + 'editorUniqID.html';

		// let belongs_to: any = this.contentDoc.body.getAttribute('isbelongTo').split('_')[1];
		// this.page_model.sectionArray.forEach((x) => {
		// 	if (x.getAttribute('id').split('_')[1] == this.contentDoc.body.getAttribute('isbelongTo').split('_')[1]) {
		// 		while (x.firstChild) {
		// 			x.removeChild(x.firstChild);
		// 		}
		// 		x.innerHTML = this.contentDoc.body.innerHTML;
		// 	}
		// })

		// let responseData = await this.editorSaveService.mappingContent(this.contentDoc.body, this.test_contentDoc, this.contentDoc, url, this.page_model, pdf);
		// let project_path = this.uploadURL + this.projectName;
		// project_path = project_path.replace(new RegExp("../pod_assets/uploads/", "g"), "/pod_assets/uploads/");
		// let data = await this.editorJsonService.createJSONfromHTML(responseData.childNodes[0].innerHTML, this.test_contentDoc, true, this.appConfig.config.hostURL + project_path);
		// if (!pdf) {
		// 	await this.resetJSONHTML(data);
		// 	this.getHTMLservice(true);
		// } else {
		// 	return new Promise((resolve, reject) => {
		// 		resolve(data)
		// 	})
		// }
		
	}

	resetJSONHTML = async function (data) {
		try {
			for (let x in data) {
				if (data[x].fileName == 'editorBodyJSON') {
					let test_data: any = {
						newData: ''
					}
					test_data.newData = data[x].data
					await this.editorSaveService.appendIframePageWiseContent(test_data, this.test_contentDoc, '', true, true)
				} else {
					await this.editorSaveService.appendIframeHeadContent(data[x].data, this.test_contentDoc, true)
				}
			}
			await this.editorHttpService.createHtml({
				head: htmlEncode(this.test_contentDoc.head.innerHTML),
				body: htmlEncode(this.test_contentDoc.body.innerHTML),
				url: this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + this.currentChapter.pc_name + '.html'
			});
			await this.editorHttpService.createHtml({
				head: htmlEncode(this.test_contentDoc.head.innerHTML),
				body: htmlEncode(this.test_contentDoc.body.innerHTML),
				url: this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + 'editorUniqID.html'
			});
			return new Promise((resolve, reject) => {
				resolve()
			})
		} catch (error) {
			console.log(error)
		}
	}



	generatePDF = async function () {
		this.spinner.show();
		//let data = await this.onSaveHtml(true);
		//await this.appendBreakCondition(this.test_contentDoc);
		this.test_contentDoc.body.innerHTML = '';
		this.page_model.sectionArray.forEach((x) => {
			x.classList.add('break_condition')
			this.test_contentDoc.body.innerHTML += x.outerHTML;
		})
		// let test_data = this.test_contentDoc.body.querySelectorAll('[class=dynamicSection]')
		// test_data.forEach((x)=>{
		// 	x.classList.add('break_condition')
		// })
		// await this.appendBreakCondition(this.test_contentDoc);
		await this.editorHttpService.createHtml({
			head: htmlEncode(this.test_contentDoc.head.innerHTML),
			body: htmlEncode(this.test_contentDoc.body.innerHTML),
			url: this.uploadURL + this.projectName + '/s9ml/' + this.currentChapter.chapter_name + '/' + this.currentChapter.pc_name + '.html'
		});
		await this.processpdfservice.test_generatePDF(this.currentChapter, 0);
		this.spinner.hide();
	}
	appendBreakCondition = async function (saveElement) {
		try {


			let array_Id: any = [];
			this.page_model.sectionArray.forEach((x) => {
				// array_Id.push(x.querySelector('[break=break_condition]'))
				array_Id.push(Array.from(x.querySelectorAll('*')).slice(-1).pop())
			})
			array_Id.forEach((x) => {
				let _Id = x.getAttribute('uniqid');
				saveElement.body.querySelector('[uniqid="' + _Id + '"]').classList.add('break_condition')
			})
			return new Promise((resolve, reject) => {
				resolve()
			})

		} catch (err) {
			if (err)
				throw err
		}
	}
    /**
     * Menu side bar navigation function
     */
	test_toc:any='';
	test_index:any='';
	changeHtml_test = function(toc, index){

			let editorSlide = document.getElementById("editor_newframe");
			if (editorSlide) {
				editorSlide.style.display = 'none';
			}
			this.test_toc = toc;
			this.test_index= index;

			this.break_continous = true;
			if(this.currentChapter.chapter_name==toc.chapter_name)
			{
			this.activatedRoute.params.subscribe(params => {
					new Promise((resolve, reject) => {
					this.getProjectDetails(params, resolve);
				})
					});
		}
			if(!this.button_disable){
				this.changeHtml(toc,index)
			
			}
	
	}	 
	// index:any;

	
	changeHtml = async function (toc, index) {
		// this.index=index;
		this.break_continous = false;
	    this.button_disable=true;

		this.firstload += 1;
		let obj = this.routePath;
		let navigationExtras: NavigationExtras = {
			queryParams: {
				'chaptername': toc.chapter_name,
				'pageno': this.pageVariable
			},
			skipLocationChange: true,
			replaceUrl: true
		};
		this.pageVariable = 1;

		this.selectedToc = toc;

		this.spinner.show();


		localStorage.setItem('chapterDetails', JSON.stringify(toc));
		this.chapterDetails = JSON.parse(localStorage.getItem('chapterDetails'));
		this.currentChapter = JSON.parse(localStorage.getItem('chapterDetails'));

		localStorage.setItem('chapterid', toc.pc_id);
		this.chaptersList.forEach(function (value) {
			if (value.chapter_name == toc.chapter_name) {
				value.select = true;
			} else {
				value.select = false;
			}
		});

				if(toc.pc_status == 0){
				 this.poptipOpen().then((result:any)=>{
				if(result!=`data`){
				this.pgno=result["page_number"];
				this.pop_tip=result["poptip_c"];
				this.twocolumn=result["twocolumn"];
			this.processpdfservice.generateHtml(toc, index, this.pgno, this.pop_tip,this.twocolumn).subscribe(
				data => {
					this.tocdetails = data;
					toc.html = true;
					this.saved_pageno = 0;
					this.getHTMLservice(false);
				})
				}else{
				this.onloadChapter();
				}
			});


				}
				else if(toc.pc_status == 1 || toc.pc_status == 2) {
			this.getHTMLservice(false);
				}
			
				} 
	
	

	/***copy */
	getContentList = function (content, type) {
		return new Promise((resolve, reject) => {
			this.tocContent = this.sanitizer.bypassSecurityTrustHtml(content);
			var elem = document.getElementById("tocContentHide");
			var contentsList;
			if (type == "epub") {
				contentsList = window.document.getElementsByTagName("content");
			} else {
				contentsList = window.document.getElementsByTagName("exhibit");
			}
			setTimeout(() => {
				resolve(contentsList);
			}, 100);
		});
	}

	getProjectDetails = async function (project, resolve) {

		this.project_id = project.id;
		await this.dataservice.getProjectData(project).subscribe(data => {
			let response = JSON.parse(data);
	
			let extension = response.project_type;
			let folder = response.project_name;
			this.projectName = folder;
			this.dataservice.getTocData(folder, extension).subscribe(toc => {
	
				this.getContentList(toc, extension).then(val => {
					this.dataservice.getchapterstatus(project, val, folder, extension).subscribe(tocstatus => {
			
						localStorage.setItem('tocstatus', JSON.stringify(tocstatus));
						this.chaptersList = tocstatus;
						this.chapterCount = this.chaptersList.length;
						this.chapterDetails=JSON.parse(localStorage.getItem('chapterDetails'));	
						
						let arr = [],
							ival;
							// console.log(this.chapterDetails,this.currentChapter);
						if (this.chapterDetails && this.chapterDetails.chapter_name != "" && typeof this.chapterDetails.chapter_name != "undefined") {
						
							this.chaptersList.forEach( (value, index) =>{
							
								if (value.chapter_name == this.chapterDetails.chapter_name) {
									// console.log(this.chapterDetails)
									value.select = true;
									arr = value;
									ival = this.test_index=index;
									this.test_toc=value;
									this.currentChapter=value;
									 if(value.pc_status == 0){
									 	this.chapterDetails='',this.currentChapter=''
									 	let keyToremove=["chapterDetails","tocstatus","chapterid"];
									 	keyToremove.forEach(k=>localStorage.removeItem(k));
									 	this.onloadChapter();
									 }

									localStorage.setItem('chapterid', value.pc_id);
									localStorage.setItem('convert_count', value.convert_count);
								}
							});
							// console.log(this.chapterDetails);
							this.pdfSrc = this.uploadURL + this.chapterDetails.folder + "/s9ml/" + this.chapterDetails.chapter_name + "/" + this.chapterDetails.chapter_name + ".pdf";
							//   this.editorservice.sendToc(arr);
							this.selectedToc = arr;
					
							// this.spinner.hide();
							//   this.showEditor(this.currentChapter,ival);
						} else {
							let currentChapter = _.where(tocstatus, {
								'pc_status': 1
							});
							if (currentChapter && currentChapter.length) {
								this.currentChapter = currentChapter[0];

								this.indexval = ival;
								// this.spinner.hide();
								resolve('completed')
							} else {
								this.currentChapter = this.chaptersList[0];
								// alert("Pdf is not available!");
							}


							this.currentChapter.select = true;
							ival = 0;
							this.pdfSrc = this.uploadURL + this.currentChapter.folder + "/s9ml/" + this.currentChapter.chapter_name + "/" + this.currentChapter.chapter_name + ".pdf";
							//   this.editorservice.sendToc(this.currentChapter);
							this.selectedToc = this.currentChapter;
							// localStorage.setItem('chapterDetails', JSON.stringify(toc));
							// this.chapterDetails = JSON.parse(localStorage.getItem('chapterDetails'));
							// console.log(this.currentChapter);
								this.chapterDetails =this.currentChapter;

							localStorage.setItem('chapterid', this.currentChapter.pc_id);
							localStorage.setItem('convert_count', this.currentChapter.convert_count);

							//setTimeout(() => {
							// this.viewer = false;
							// this.showEditor(this.currentChapter,ival)
							//}, 2000);
							this.indexval = ival;
							// this.spinner.hide();
							if (currentChapter.length > 0) {
								resolve('completed')
							} else {
								tocstatus[0].startPageNumber = 1
								this.processpdfservice.generateHtml(tocstatus[0], 0, 1, true, false).subscribe(
									data => {
										this.tocdetails = data;
										// toc.html=true;
										this.getHTMLservice(false);
										// 
									})
							}
						}

					});
				});
			});


		});
	}

	textFormat(type, status, listType) {
		var tag;
		let formatType = type.toUpperCase();
		//const contentWindow = this.editorFramewindow.contentWindow;
		const contentWindow = this.iframeElement.nativeElement.contentWindow;

		if (contentWindow.getSelection) {
			this.selectedElement = contentWindow.getSelection().toString();
			var selection = contentWindow.getSelection();
			var range = selection.getRangeAt(0);
			if (formatType == "BOLD") {
				this.actionBold = status == true ? false : true;
				contentWindow.document.execCommand('bold', false, null);
			} else if (formatType == "BLOCK") {
				this.actionBlock = status == true ? false : true;
				contentWindow.document.execCommand('formatBlock', false, 'div');
			} else if (formatType == "P") {
				this.actionP = status == true ? false : true;
				contentWindow.document.execCommand('formatBlock', false, 'p');
			}
			else if (formatType == "ITALIC") {
				this.actionItalic = status == true ? false : true;
				contentWindow.document.execCommand('italic', false, null);
			} else if (formatType == "UNDERLINE") {
				this.actionUnderline = status == true ? false : true;
				contentWindow.document.execCommand('underline', false, null);
			} else if (formatType == "STRIKE") {
				this.actionStrike = status == true ? false : true;
				contentWindow.document.execCommand('strikeThrough', false, null);
			} else if (formatType == "SUPERSCRIPT") {
				this.actionSuper = status == true ? false : true;
				contentWindow.document.execCommand('superscript', false, null);
			} else if (formatType == "SUBSCRIPT") {
				this.actionSub = status == true ? false : true;
				contentWindow.document.execCommand('subscript', false, null);
			} else if (formatType == "H1") {
				this.actionH1 = status == true ? false : true;
				var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				contentWindow.document.execCommand('insertHTML', false, "<h1>" + highlight + "</h1>");
			} else if (formatType == "H2") {
				this.actionH2 = status == true ? false : true;
				var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				contentWindow.document.execCommand('insertHTML', false, "<h2>" + highlight + "</h2>");
			} else if (formatType == "CREATELINK") {
				this.actionCreateLink = status == true ? false : true;

				// this.dialogRef = this.dialog.open(modelDialogComponent,{
				// 	height: '200px',
				// 	width: '400px',
				// 	data: {page:"createlink",createlink:"http://"}
				// });
				//   this.dialogRef.afterClosed().subscribe(result => {
				// 	if(result.status == "save"){
				// 		this.createlink = result.createlink;
				// 		if(this.createlink != ""){
				// 			var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				// 			contentWindow.document.execCommand('insertHTML', false,'<a href="' + this.createlink + '" target="_blank">' + highlight + '</a>');
				// 		}

				// 	}

				//   });


			}
			else if (formatType === 'RIHGTALLIGN') {
				this.rightAllign = status == true ? false : true;
				contentWindow.document.execCommand("JustifyRight", false, "");
			}
			else if (formatType === 'LEFTALLIGN') {
				this.leftAllign = status == true ? false : true;
				contentWindow.document.execCommand("justifyLeft", false, "");
			}
			else if (formatType === 'CENTERALLIGN') {
				this.centerAllign = status == true ? false : true;
				contentWindow.document.execCommand("justifyCenter", false, "");
			}
			else if (formatType === 'FORECOLOR') {
				this.foreColor = status == true ? false : true;
				this.colorPicker = !this.colorPicker;
				// contentWindow.document.execCommand("ForeColor", false, "red");
			}
			else if (formatType == "UNLINK") {
				this.actionUnLink = status == true ? false : true;
				contentWindow.document.execCommand('unlink', false, false);
			} else if (formatType == "INDENT") {
				this.actionIndent = status == true ? false : true;
				contentWindow.document.execCommand('indent', false, null);
			}else if (formatType == "ORDEREDLIST") {
				this.actionOl = status == true ? false : true;
				var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				var parentChild = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.localName;
				var closestOl = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.closest('ol');
				if (closestOl && closestOl.tagName.toLowerCase() === 'ol') {
					switch (listType) {
						case 'A': {
							closestOl.setAttribute('style', "list-style-type: upper-alpha");
							break;
						}
						case 'a': {
							closestOl.setAttribute('style', "list-style-type: lower-alpha");
							break;
						} 
						case '1': {
							closestOl.setAttribute('style', "list-style-type: decimal");
							break;
						} 
					}
				} else {
					if (parentChild == "ol" || parentChild == "ul") {
						var node = document.createElement("LI"); // Create a <li> node
						var textnode = document.createTextNode(highlight); // Create a text node
						node.appendChild(textnode);
						contentWindow.document.execCommand('delete'); // Delete the highlighted text
						contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.appendChild(node);
					} else {
						contentWindow.document.execCommand('insertorderedlist', false, null);
					}
				}
			}
			// else if (formatType == "ORDEREDLISTTYPEA") {
			// 	this.actionOl = status == true ? false : true;
			// 	var highlight = contentWindow.getSelection().getRangeAt(0).toString();
			// 	var parentChild = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.localName;
			// 	var closestOl = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.closest('ol');
			// 	if(closestOl.tagName.toLowerCase() === 'ol') {
			// 		closestOl.setAttribute('style', "list-style-type: lower-alpha")
			// 	// if (parentChild == "ol" || parentChild == "ul") {
			// 		// closestOl.setAttribute('type', 'A');
			// 		// var node = document.createElement("LI"); // Create a <li> node
			// 		// var textnode = document.createTextNode(highlight); // Create a text node
			// 		// node.appendChild(textnode);
			// 		// contentWindow.document.execCommand('delete'); // Delete the highlighted text
			// 		// contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.appendChild(node);
			// 	} else {
			// 		contentWindow.document.execCommand('insertorderedlist', false, null);
			// 	}
			// }
			else if (formatType == "UNORDEREDLIST") {
				this.actionUl = status == true ? false : true;
				var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				var parentChild = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.localName;
				if (parentChild == "ol" || parentChild == "ul") {
					var node = document.createElement("LI"); // Create a <li> node
					var textnode = document.createTextNode(highlight); // Create a text node
					node.appendChild(textnode);
					contentWindow.document.execCommand('delete'); // Delete the highlighted text
					contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.offsetParent.appendChild(node);

				} else {
					contentWindow.document.execCommand('insertUnorderedList', false, null);
				}
			} else if (formatType == "INSERTHTML") {
				var highlight = contentWindow.getSelection().getRangeAt(0).toString();
				var lengthHighlight = contentWindow.getSelection().getRangeAt(0).commonAncestorContainer.parentNode.attributes;

				if (lengthHighlight.length == 1 && (lengthHighlight[0].ownerElement.localName == "span" && lengthHighlight[0].ownerElement.className == "page-break")) {
					contentWindow.document.execCommand('insertHTML', false, '<span>' + highlight + '</span>');
				} else {
					contentWindow.document.execCommand('insertHTML', false, '<span class="page-break">' + highlight + '</span>');
				}

				this.actionPageBreak = status == true ? false : true;
			}

		}
	}

	handleColor = ($event: ColorEvent) => {
		const contentWindow = this.iframeElement.nativeElement.contentWindow;
		if (contentWindow.getSelection) {
			contentWindow.document.execCommand("ForeColor", false, $event.color.hex);
			this.colorPicker = true;
		}
	}

	poptipOpen() {
		  
		return new Promise(resolve=>{
		   this.modalService.open(ModalboxComponent,{backdrop: 'static'}).result.then((result) => {
			   resolve(result)
			 }, (reason) => {
			 	 console.log(reason);
			    //newly added
			    this.chapterDetails='',this.currentChapter=''
			      let keyToremove=["chapterDetails","tocstatus","chapterid"];
			      keyToremove.forEach(k=>
			        localStorage.removeItem(k));
     			 resolve(`data`);
			   console.log( `Dismissed `);
			   
			 });
			   //resolve('')
			   //   setTimeout(() => resolve(this.pop_tip), 3000);
		   })

		   

	 }

	 onloadChapter(){
	 	this.spinner.show();
		let promise: any = '';
		this.activatedRoute.params.subscribe(params => {
			if (localStorage.getItem('tocstatus') && localStorage.getItem('chapterid')) {
				
				this.chaptersList = JSON.parse(localStorage.getItem('tocstatus'));
				let currentChapterid = localStorage.getItem('chapterid');
				this.currentChapter = _.where(this.chaptersList, {
					'pc_id': Number(currentChapterid)
				})[0];
				// this.chapterDetails=this.currentChapter;
				localStorage.setItem('chapterDetails', JSON.stringify(this.currentChapter));


					this.projectName = this.chaptersList[0].folder;
				this.chapterCount = this.chaptersList.length;
				this.currentChapter.select = true;
				// console.log("chapterDetails",this.chapterDetails);
					promise = new Promise((resolve, reject) => {
					this.getProjectDetails(params, resolve);
				})
					
					
			
				this.getHTMLservice(false);
				// this.getHTMLservice(false);
				
				// 	promise = new Promise((resolve, reject) => {
				// 	resolve('completed')
				// })

					// console.log(this.chaptersList.indexOf( 'chapter01'));
	
			
			
				} else {
				promise = new Promise((resolve, reject) => {
					this.getProjectDetails(params, resolve);
				})


			}
			
		});

		this.activatedRoute.url.subscribe(urlsegments => {
				urlsegments.forEach(segment => {
				this.routerSegments.push(segment.path);
			});
		});

		this.page_model.sectionCount = 0,
			promise.then((data) => {
				this.getHTMLservice(false);
			})

	
		this.editorDomService.test_subject.subscribe((data)=>{
		this.nodeToDelete = data;
			})

		this.editorDomService.list_subject.subscribe((data) => {
			this.isTypeList = data;
		})


		this.editorDomService.subject.subscribe((data) => {
		this.page_model.sectionArray = data.sectionArray;
		this.page_model.iframeBody = data.iframeBody,
		this.page_model.sectionCount = data.sectionCount,
		this.page_model.json = data.json;
		this.page_model.isRecursive = data.isRecursive

			if (this.page_model.isRecursive) {
				let section = this.renderer.createElement('section');
				this.renderer.setAttribute(section, 'id', 'section_' + this.page_model.sectionCount);
				this.renderer.addClass(section, 'dynamicSection');
				section.innerHTML = this.page_model.iframeBody.innerHTML;
				this.page_model.sectionArray.push(section);
				this.createUniqIdHTML()
			}

		})

	 }
	 headerValue(){
	var ischapter;
	var allTags = this.iframeElement_test.nativeElement.contentDocument
	if(allTags!=''&&allTags!=null){
    var headertags=allTags.getElementsByTagName('header');                      
    var styles = ["color", "font-family", "font-size", "line-height", "white-space", "padding", "display", "float", "border", "border-top", "border-right", "border-bottom", "border-left", "border-color", "border-width", "border-style", "padding-top", "padding-right", "padding-bottom", "padding-left","width", "height", "font-weight", "margin-top", "margin-left", "margin-bottom", "margin-right", "text-decoration","background-color","background-image","font-style","position","text-align","vertical-align","top","left","bottom","right","word-wrap"];
    var setchpno=false;   
    
        
     
    for (var cn = 0; cn < headertags.length; cn++) {        
        
        if (headertags[cn].getElementsByClassName("chapter-number").length > 0){
            ischapter=headertags[cn].getElementsByClassName("chapter-number");
        }else if (headertags[cn].getElementsByClassName("number").length > 0){
            ischapter=headertags[cn].getElementsByClassName("number");
        }else if (headertags[cn].getElementsByClassName("mhhe-chapter_opener-chapter_number").length > 0){
            ischapter=headertags[cn].getElementsByClassName("mhhe-chapter_opener-chapter_number");
        }


        if (ischapter) {
 
        	
            for (var hc = 0; hc < ischapter.length; hc++) {
                var cn_html=ischapter[hc].innerHTML.replace(/<\/?[^>]+(>|$)/g, "").toLowerCase();
                if(cn_html.indexOf('part') === -1){
                    var txt='Chapter';
                    var cp_class='chp-no';
                }else{
                    var txt='Part';
                    var cp_class='part-no';
                }
                 cn_html=cn_html.replace(txt,'').replace(/\s/g,'').replace(/:/g,'');
              
                    if (headertags[cn].getElementsByClassName("mhhe-chapter_opener-chapter_title").length > 0){
                     	  ischapter=headertags[cn].getElementsByClassName("mhhe-chapter_opener-chapter_title");
                     	var cnew_html=ischapter[hc].innerHTML.replace(/<\/?[^>]+(>|$)/g, "");
                     }
                 

                if (headertags[cn]) {

                     this.chapterinfo=cn_html+': '+cnew_html;
      
                    setchpno=true;
                }
                
            }
        } 
            
        if (setchpno==true) {
            break;
        }               
    }
}
else
	{	this.chapterinfo="";ischapter="";
	}
    return true;
	 }
	 
	 editorClose = () => {
		this.eventArrayHandler();
		let editorSlide = document.getElementById("editor_newframe");
		if (editorSlide) {
			editorSlide.style.display = 'none';
		}
	}

	eventArrayHandler = () => {
		this.editorDomService.eventArray && this.editorDomService.eventArray.map((elem) => {
			if (elem && elem.target) {
				elem.target.style.border = "";
                elem.target.style.boxShadow = "";
                elem.target.style.padding = ""
                elem.target.style.borderRadius = ""
			}
			if (elem.target && elem.target.parentNode) {
				elem.target.parentNode.style.border = "";
                elem.target.parentNode.style.boxShadow = "";
                elem.target.parentNode.style.padding = ""
                elem.target.parentNode.style.borderRadius = ""
			}
			if (elem.target && elem.target.parentNode && elem.target.parentNode.parentNode) {
				elem.target.parentNode.parentNode.style.border = "";
				elem.target.parentNode.parentNode.style.border = "";
				elem.target.parentNode.parentNode.style.boxShadow = "";
				elem.target.parentNode.parentNode.style.padding = ""
				elem.target.parentNode.parentNode.style.borderRadius = ""
			}
		})
	}
}